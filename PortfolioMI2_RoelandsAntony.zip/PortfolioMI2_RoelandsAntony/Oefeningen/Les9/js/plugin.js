(function ($) {
    $.fn.ControleerDeTemperatuur = function() {
        
    $("tbody tr td:contains('-')").css("background-color", "#06FBFB");
    $("tbody tr td:contains('C')").not(":contains('-')").css("background-color", "green");
    

    }
}) (jQuery);