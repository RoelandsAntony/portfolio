var scherm=$('#spelzone').position().left;
//var schermRechts = schermLinks + $('#spelzone').width();
//var schermTop = scherm.top;
//var schermOnder = schermTop + $('#spelzone').height();
var positiePika=$("#pika").position().left;
var positieAsh=$("#ash").position().left;
var positieBal=$("#bal").position().left;
var positieBalCol=(positieBal+500);
function werpen() {
$("#bal").animate({
marginLeft:"96%"
},1000);
setInterval(function() {//Zorgt ervoor dat de afbeelding nog voor 100 ms op het scherm staat
checkPositieBal();
},100);
document.getElementById("bal").style.display='block';
$("#bal").css({
"top":$("#ash").position().top,"left":$("#ash").position().left
})
function checkPositieBal() {
var positieBal=$("#bal").position().left;
var positieBalCol=(positieBal+200);
}
gevangen();
terug();
};
function terug() {
$("#bal").css({
"top":$("#ash").position().top,"left":$("#ash").position().left
})
}
function gewonnen() {
if(balleven===0) {
window.open("Gewonnen.html", "_self");
console.log("gewonnen")
}
if(balleven===1) {
window.open("pokemonVerloren.html", "_self");
console.log("verloren")
}
}
var balleven=1;
function gevangen() {
if(Math.abs(positieBalCol==positiePika)<1.0E-8) {
$("#pika").fadeOut(10);
console.log("collision");
$("#balLeven1").fadeOut(1000);
$("#bal").fadeOut();( balleven=0);
console.log(balleven);
}
}
function vangPika() {
$('body').keyup(function(e) {
if(e.keyCode===32) {
werpen();
setTimeout(function() {
gewonnen()
},2500);
}
});
}
$(document).ready(function() {
vangPika();
});