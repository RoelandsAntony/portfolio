"use strict";
/*global $, console
 */
function goPika() {
$("#pika").animate({
left:'5px'
},2500);
setInterval(function() {//Zorgt ervoor dat de afbeelding nog voor 100 ms op het scherm staat
checkPositie();
},100);
function checkPositie() {
var positiePika=$("#pika").position().left;
}
}
$(document).ready(function() {
goPika();
console.log("klaar");
});
